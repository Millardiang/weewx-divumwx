<?php
$templateversion = "DVM-<maxblue>Alpha build 0.4.25</maxblue>";
?>