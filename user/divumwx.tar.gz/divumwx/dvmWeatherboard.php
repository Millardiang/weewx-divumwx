<?php
include('dvmCombinedData.php');
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <link rel="icon" type="image/png" href="favicon.ico">
      <title>Steeple Claydon, UK</title>
    <meta name="description" content="Up to date divum readings for Steeple Claydon, UK.">
  </head>
  <body style="background-color:black;font-family:monospace;color:#00FFFF;">


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id="></script>
<script>
  var host = location.host;
  if (host == "") {
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '');
  }
</script>

<script>
    page_update_pwd = 'foobar';
    refresh_rate = 2;
    expiration_time = 4;
  function addLoadEvent(func) {
    var oldonload = window.onload;
    if (typeof window.onload != 'function') {
      window.onload = func;
    } else {
      window.onload = function() {
        if (oldonload) {
          oldonload();
        }
        func();
      }
    }
  }
  function getUrlParam(paramName) {
      var name, regexS, regex, results;
      name = paramName.replace(/(\[|\])/g, '\$1');
      regexS = '[\\?&]' + name + '=([^&#]*)';
      regex = new RegExp(regexS);
      results = regex.exec(window.location.href);
      if (results === null) {
          return '';
      } else {
          return results[1];
      }
  }
  var pageTimedOut = false;
  function expirePage() {
    pageTimedOut = true;
  }
  function setUpExpiredClickListener() {
    var liveLabel = document.getElementById("live-label");
    if (liveLabel != "CLICK-ME") {
      liveLabel.innerHTML = "CLICK-ME";
      // set an onclick event on live-label to restart everything
      liveLabel.addEventListener("click", clickListener);
    }
  }
  function clickListener() {
    // disable the onClick event again
    var liveLabel = document.getElementById("live-label");
    liveLabel.removeEventListener('click', clickListener);
    liveLabel.innerHTML = "";
    // restart everything
    pageTimedOut = false;
    // restart the page timeout
    setPageExpirationTimer();
  }
  function setPageExpirationTimer() {
    if (getUrlParam('pageUpdate') !== page_update_pwd) {
      // expire in N hours
      setTimeout(expirePage, 1000 * 60 * 60 * expiration_time);
    }
  }
  setPageExpirationTimer();
  setInterval(updateCurrent, 2000);
  addLoadEvent(updateCurrent);

  function updateCurrent() {
    if (pageTimedOut) {
        setUpExpiredClickListener();
        return false;
    }
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function() {
      try {
        var result = JSON.parse(this.responseText);

        // Check the date
        // "dateTime": 1578965850,
        var lastUpdate = new Date(result["current.dateTime.raw"] * 1000);
        var age = Math.round(Math.abs(new Date() - lastUpdate) / 1000);
        var element = document.getElementById("live-label");
        element.style.fontWeight = "bolder";
        if (age <= 6) {
          element.innerHTML = "LIVE&nbsp;&nbsp;";
        } else {
          element.innerHTML = age + "s ago&nbsp;&nbsp;";
        }

        // Display the time of the last update.
        var activityElement = document.getElementById("last-update");
        activityElement.innerHTML = lastUpdate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second:'2-digit'});

        // Trend
        if (result.hasOwnProperty("trend.outTemp")) {
          document.getElementById("trend.outTemp").innerHTML = result["trend.outTemp"];
        } else {
          document.getElementById("trend.outTemp").innerHTML = '';
        }
        if (result.hasOwnProperty("trend.barometer.desc")) {
          document.getElementById("trend.barometer.desc").innerHTML = result["trend.barometer.desc"];
        } else {
          document.getElementById("trend.barometer.desc").innerHTML = '';
        }
        // Current
        if (result.hasOwnProperty("current.outTemp.formatted")) {
          document.getElementById("current.outTemp.formatted").innerHTML = result["current.outTemp.formatted"].padStart(5,' ');
        } else {
          document.getElementById("current.outTemp.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("current.dewpoint.formatted")) {
          // dew point
          document.getElementById("current.dewpoint.formatted").innerHTML = result["current.dewpoint.formatted"].padStart(5,' ');
        } else {
          document.getElementById("current.dewpoint.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("current.windSpeed.formatted")) {
          document.getElementById("current.windSpeed.formatted").innerHTML = result["current.windSpeed.formatted"].padStart(5,' ');
          var windBearing = ''.padStart(4, ' ').padEnd(5,' ');
          if (result["current.windSpeed.formatted"] != 0.0) {
            if (result.hasOwnProperty("current.windDir.ordinal_compass")) {
              windBearing = result["current.windDir.ordinal_compass"].padStart(4, ' ').padEnd(5,' ');
            } else {
            }
          }
          document.getElementById("current.windDir.ordinal_compass").innerHTML = windBearing;
        } else {
          document.getElementById("current.windSpeed.formatted").innerHTML = ''.padStart(5,' ');
          document.getElementById("current.windDir.ordinal_compass").innerHTML = ''.padEnd(3,' ');
        }
        if (result.hasOwnProperty("current.rainRate.formatted")) {
          document.getElementById("current.rainRate.formatted").innerHTML = result["current.rainRate.formatted"].padStart(5,' ');
        } else {
          document.getElementById("current.rainRate.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("2m.outTemp.max.formatted")) {
          document.getElementById("2m.outTemp.max.formatted").innerHTML = result["2m.outTemp.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("2m.outTemp.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("2m.outTemp.min.formatted")) {
          document.getElementById("2m.outTemp.min.formatted").innerHTML = result["2m.outTemp.min.formatted"].padStart(5,' ');
        } else {
          document.getElementById("2m.outTemp.min.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("2m.wind.rms.formatted")) {
          document.getElementById("2m.wind.rms.formatted").innerHTML = result["2m.wind.rms.formatted"].padStart(5,' ');
        } else {
          document.getElementById("2m.wind.rms.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("2m.windGust.max.formatted")) {
          document.getElementById("2m.windGust.max.formatted").innerHTML = result["2m.windGust.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("2m.windGust.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("2m.rain.sum.formatted")) {
          document.getElementById("2m.rain.sum.formatted").innerHTML = result["2m.rain.sum.formatted"].padStart(5,' ');
        } else {
          document.getElementById("2m.rain.sum.formatted").innerHTML = '';
        }
        if (result.hasOwnProperty("10m.outTemp.max.formatted")) {
          document.getElementById("10m.outTemp.max.formatted").innerHTML = result["10m.outTemp.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("10m.outTemp.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("10m.outTemp.min.formatted")) {
          document.getElementById("10m.outTemp.min.formatted").innerHTML = result["10m.outTemp.min.formatted"].padStart(5,' ');
        } else {
          document.getElementById("10m.outTemp.min.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("10m.wind.rms.formatted")) {
          document.getElementById("10m.wind.rms.formatted").innerHTML = result["10m.wind.rms.formatted"].padStart(5,' ');
        } else {
          document.getElementById("10m.wind.rms.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("10m.windGust.max.formatted")) {
          document.getElementById("10m.windGust.max.formatted").innerHTML = result["10m.windGust.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("10m.windGust.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("10m.rain.sum.formatted")) {
          document.getElementById("10m.rain.sum.formatted").innerHTML = result["10m.rain.sum.formatted"].padStart(5,' ');
        } else {
          document.getElementById("10m.rain.sum.formatted").innerHTML = '';
        }
        if (result.hasOwnProperty("24h.outTemp.max.formatted")) {
          document.getElementById("24h.outTemp.max.formatted").innerHTML = result["24h.outTemp.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("24h.outTemp.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("24h.outTemp.min.formatted")) {
          document.getElementById("24h.outTemp.min.formatted").innerHTML = result["24h.outTemp.min.formatted"].padStart(5,' ');
        } else {
          document.getElementById("24h.outTemp.min.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("24h.wind.rms.formatted")) {
          document.getElementById("24h.wind.rms.formatted").innerHTML = result["24h.wind.rms.formatted"].padStart(5,' ');
        } else {
          document.getElementById("24h.wind.rms.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("24h.windGust.max.formatted")) {
          document.getElementById("24h.windGust.max.formatted").innerHTML = result["24h.windGust.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("24h.windGust.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("24h.rain.sum.formatted")) {
          document.getElementById("24h.rain.sum.formatted").innerHTML = result["24h.rain.sum.formatted"].padStart(5,' ');
        } else {
          document.getElementById("24h.rain.sum.formatted").innerHTML = '';
        }
        if (result.hasOwnProperty("hour.outTemp.max.formatted")) {
          document.getElementById("hour.outTemp.max.formatted").innerHTML = result["hour.outTemp.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("hour.outTemp.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("hour.outTemp.min.formatted")) {
          document.getElementById("hour.outTemp.min.formatted").innerHTML = result["hour.outTemp.min.formatted"].padStart(5,' ');
        } else {
          document.getElementById("hour.outTemp.min.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("hour.wind.rms.formatted")) {
          document.getElementById("hour.wind.rms.formatted").innerHTML = result["hour.wind.rms.formatted"].padStart(5,' ');
        } else {
          document.getElementById("hour.wind.rms.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("hour.windGust.max.formatted")) {
          document.getElementById("hour.windGust.max.formatted").innerHTML = result["hour.windGust.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("hour.windGust.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("hour.rain.sum.formatted")) {
          document.getElementById("hour.rain.sum.formatted").innerHTML = result["hour.rain.sum.formatted"].padStart(5,' ');
        } else {
          document.getElementById("hour.rain.sum.formatted").innerHTML = '';
        }
        if (result.hasOwnProperty("day.outTemp.max.formatted")) {
          document.getElementById("day.outTemp.max.formatted").innerHTML = result["day.outTemp.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("day.outTemp.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("day.outTemp.min.formatted")) {
          document.getElementById("day.outTemp.min.formatted").innerHTML = result["day.outTemp.min.formatted"].padStart(5,' ');
        } else {
          document.getElementById("day.outTemp.min.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("day.wind.rms.formatted")) {
          document.getElementById("day.wind.rms.formatted").innerHTML = result["day.wind.rms.formatted"].padStart(5,' ');
        } else {
          document.getElementById("day.wind.rms.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("day.windGust.max.formatted")) {
          document.getElementById("day.windGust.max.formatted").innerHTML = result["day.windGust.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("day.windGust.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("day.rain.sum.formatted")) {
          document.getElementById("day.rain.sum.formatted").innerHTML = result["day.rain.sum.formatted"].padStart(5,' ');
        } else {
          document.getElementById("day.rain.sum.formatted").innerHTML = '';
        }
        if (result.hasOwnProperty("week.outTemp.max.formatted")) {
          document.getElementById("week.outTemp.max.formatted").innerHTML = result["week.outTemp.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("week.outTemp.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("week.outTemp.min.formatted")) {
          document.getElementById("week.outTemp.min.formatted").innerHTML = result["week.outTemp.min.formatted"].padStart(5,' ');
        } else {
          document.getElementById("week.outTemp.min.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("week.wind.rms.formatted")) {
          document.getElementById("week.wind.rms.formatted").innerHTML = result["week.wind.rms.formatted"].padStart(5,' ');
        } else {
          document.getElementById("week.wind.rms.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("week.windGust.max.formatted")) {
          document.getElementById("week.windGust.max.formatted").innerHTML = result["week.windGust.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("week.windGust.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("week.rain.sum.formatted")) {
          document.getElementById("week.rain.sum.formatted").innerHTML = result["week.rain.sum.formatted"].padStart(5,' ');
        } else {
          document.getElementById("week.rain.sum.formatted").innerHTML = '';
        }
        if (result.hasOwnProperty("month.outTemp.max.formatted")) {
          document.getElementById("month.outTemp.max.formatted").innerHTML = result["month.outTemp.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("month.outTemp.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("month.outTemp.min.formatted")) {
          document.getElementById("month.outTemp.min.formatted").innerHTML = result["month.outTemp.min.formatted"].padStart(5,' ');
        } else {
          document.getElementById("month.outTemp.min.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("month.wind.rms.formatted")) {
          document.getElementById("month.wind.rms.formatted").innerHTML = result["month.wind.rms.formatted"].padStart(5,' ');
        } else {
          document.getElementById("month.wind.rms.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("month.windGust.max.formatted")) {
          document.getElementById("month.windGust.max.formatted").innerHTML = result["month.windGust.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("month.windGust.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("month.rain.sum.formatted")) {
          document.getElementById("month.rain.sum.formatted").innerHTML = result["month.rain.sum.formatted"].padStart(5,' ');
        } else {
          document.getElementById("month.rain.sum.formatted").innerHTML = '';
        }
        if (result.hasOwnProperty("year.outTemp.max.formatted")) {
          document.getElementById("year.outTemp.max.formatted").innerHTML = result["year.outTemp.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("year.outTemp.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("year.outTemp.min.formatted")) {
          document.getElementById("year.outTemp.min.formatted").innerHTML = result["year.outTemp.min.formatted"].padStart(5,' ');
        } else {
          document.getElementById("year.outTemp.min.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("year.wind.rms.formatted")) {
          document.getElementById("year.wind.rms.formatted").innerHTML = result["year.wind.rms.formatted"].padStart(5,' ');
        } else {
          document.getElementById("year.wind.rms.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("year.windGust.max.formatted")) {
          document.getElementById("year.windGust.max.formatted").innerHTML = result["year.windGust.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("year.windGust.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("year.rain.sum.formatted")) {
          document.getElementById("year.rain.sum.formatted").innerHTML = result["year.rain.sum.formatted"].padStart(5,' ');
        } else {
          document.getElementById("year.rain.sum.formatted").innerHTML = '';
        }
        if (result.hasOwnProperty("rainyear.outTemp.max.formatted")) {
          document.getElementById("rainyear.outTemp.max.formatted").innerHTML = result["rainyear.outTemp.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("rainyear.outTemp.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("rainyear.outTemp.min.formatted")) {
          document.getElementById("rainyear.outTemp.min.formatted").innerHTML = result["rainyear.outTemp.min.formatted"].padStart(5,' ');
        } else {
          document.getElementById("rainyear.outTemp.min.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("rainyear.wind.rms.formatted")) {
          document.getElementById("rainyear.wind.rms.formatted").innerHTML = result["rainyear.wind.rms.formatted"].padStart(5,' ');
        } else {
          document.getElementById("rainyear.wind.rms.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("rainyear.windGust.max.formatted")) {
          document.getElementById("rainyear.windGust.max.formatted").innerHTML = result["rainyear.windGust.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("rainyear.windGust.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("rainyear.rain.sum.formatted")) {
          document.getElementById("rainyear.rain.sum.formatted").innerHTML = result["rainyear.rain.sum.formatted"].padStart(5,' ');
        } else {
          document.getElementById("rainyear.rain.sum.formatted").innerHTML = '';
        }
        if (result.hasOwnProperty("alltime.outTemp.max.formatted")) {
          document.getElementById("alltime.outTemp.max.formatted").innerHTML = result["alltime.outTemp.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("alltime.outTemp.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("alltime.outTemp.min.formatted")) {
          document.getElementById("alltime.outTemp.min.formatted").innerHTML = result["alltime.outTemp.min.formatted"].padStart(5,' ');
        } else {
          document.getElementById("alltime.outTemp.min.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("alltime.wind.rms.formatted")) {
          document.getElementById("alltime.wind.rms.formatted").innerHTML = result["alltime.wind.rms.formatted"].padStart(5,' ');
        } else {
          document.getElementById("alltime.wind.rms.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("alltime.windGust.max.formatted")) {
          document.getElementById("alltime.windGust.max.formatted").innerHTML = result["alltime.windGust.max.formatted"].padStart(5,' ');
        } else {
          document.getElementById("alltime.windGust.max.formatted").innerHTML = ''.padStart(5,' ');
        }
        if (result.hasOwnProperty("alltime.rain.sum.formatted")) {
          document.getElementById("alltime.rain.sum.formatted").innerHTML = result["alltime.rain.sum.formatted"].padStart(5,' ');
        } else {
          document.getElementById("alltime.rain.sum.formatted").innerHTML = '';
        }
      } catch (e) {
        console.log(e);
      }
    }
    xhttp.onerror = function() {
      console.log(e);
    }
    try {
      xhttp.open("GET", "dvmSensorData.json", true);
      xhttp.send();
    } catch (e) {
      console.log(e);
    }
  }
  function decode_rgb(i) {
    var red   = i >> 16;
    var green = (i & 0xFF00) >> 8;
    var blue  = i & 0xFF;
    return `rgb(${red},${green},${blue})`
  }
</script>
    <div>
      <div>
        <table style="font-size:32px;width:100%;margin:auto;">
          <tr>
            <td style="text-align:left;width:220px;">
              <span id="last-update"></span>
            </td>
            <td style="text-align:center;">
              <h1 style="font-size:32px;text-decoration:underline;">
                  Steeple Claydon, UK
              </h1>
            </td>
            <td style="text-align:right;width:220px;">
              <span id="live-label"></span>
            </td>
          </tr>
        </table>
      </div>
    </div>
    <div style="font-size:60px;text-align:center;">
      <span style="font-size:32px;">Current</span>
      <div style="font-size:20px;">
        Temperature Trend: <?php echo $temp["outside_trend"];?></span>
        &mdash;
        Barometer Trend: <span id="trend.barometer.desc"></span>
      </div>
      <table style="width:100%;margin:auto;">
        <tr>
          <td style="font-size:20px;">Out Temp</td>
          <td style="font-size:20px;">Dew Pt</td>
          <td style="font-size:20px;">Wind Sp</td>
          <td style="font-size:20px;">Wind Dir</td>
          <td style="font-size:20px;">Rain Rate</td>
        </tr>
        <tr>
          <td id="current.outTemp.formatted" style='white-space:pre;'></td>
          <td id="current.dewpoint.formatted" style='white-space:pre;'></td>
          <td id="current.windSpeed.formatted" style='white-space:pre;'></td>
          <td id="current.windDir.ordinal_compass" style='white-space:pre;'></td>
          <td id="current.rainRate.formatted" style='white-space:pre;'></td>
        </tr>
      </table>
      <span style="font-size:32px;">Last 2 Minutes</span>
      <table style="width:100%;margin:auto;">
        <tr>
          <td style="font-size:20px;">Hi Out Temp</td>
          <td style="font-size:20px;">Lo Out Temp</td>
          <td style="font-size:20px;">Wind RMS</td>
          <td style="font-size:20px;">Hi Gust</td>
          <td style="font-size:20px;">Rain</td>
        </tr>
        <tr>
          <td id='2m.outTemp.max.formatted' style='white-space:pre;'></td>
          <td id='2m.outTemp.min.formatted' style='white-space:pre;'></td>
          <td id='2m.wind.rms.formatted' style='white-space:pre;'></td>
          <td id='2m.windGust.max.formatted' style='white-space:pre;'></td>
          <td id='2m.rain.sum.formatted' style='white-space:pre;'></td>
        </tr>
      </table>
      <span style="font-size:32px;">Last 10 Minutes</span>
      <table style="width:100%;margin:auto;">
        <tr>
          <td style="font-size:20px;">Hi Out Temp</td>
          <td style="font-size:20px;">Lo Out Temp</td>
          <td style="font-size:20px;">Wind RMS</td>
          <td style="font-size:20px;">Hi Gust</td>
          <td style="font-size:20px;">Rain</td>
        </tr>
        <tr>
          <td id='10m.outTemp.max.formatted' style='white-space:pre;'></td>
          <td id='10m.outTemp.min.formatted' style='white-space:pre;'></td>
          <td id='10m.wind.rms.formatted' style='white-space:pre;'></td>
          <td id='10m.windGust.max.formatted' style='white-space:pre;'></td>
          <td id='10m.rain.sum.formatted' style='white-space:pre;'></td>
        </tr>
      </table>
      <span style="font-size:32px;">Last 24 Hours</span>
      <table style="width:100%;margin:auto;">
        <tr>
          <td style="font-size:20px;">Hi Out Temp</td>
          <td style="font-size:20px;">Lo Out Temp</td>
          <td style="font-size:20px;">Wind RMS</td>
          <td style="font-size:20px;">Hi Gust</td>
          <td style="font-size:20px;">Rain</td>
        </tr>
        <tr>
          <td id='24h.outTemp.max.formatted' style='white-space:pre;'></td>
          <td id='24h.outTemp.min.formatted' style='white-space:pre;'></td>
          <td id='24h.wind.rms.formatted' style='white-space:pre;'></td>
          <td id='24h.windGust.max.formatted' style='white-space:pre;'></td>
          <td id='24h.rain.sum.formatted' style='white-space:pre;'></td>
        </tr>
      </table>
      <span style="font-size:32px;">Hour</span>
      <table style="width:100%;margin:auto;">
        <tr>
          <td style="font-size:20px;">Hi Out Temp</td>
          <td style="font-size:20px;">Lo Out Temp</td>
          <td style="font-size:20px;">Wind RMS</td>
          <td style="font-size:20px;">Hi Gust</td>
          <td style="font-size:20px;">Rain</td>
        </tr>
        <tr>
          <td id='hour.outTemp.max.formatted' style='white-space:pre;'></td>
          <td id='hour.outTemp.min.formatted' style='white-space:pre;'></td>
          <td id='hour.wind.rms.formatted' style='white-space:pre;'></td>
          <td id='hour.windGust.max.formatted' style='white-space:pre;'></td>
          <td id='hour.rain.sum.formatted' style='white-space:pre;'></td>
        </tr>
      </table>
      <span style="font-size:32px;">Today</span>
      <table style="width:100%;margin:auto;">
        <tr>
          <td style="font-size:20px;">Hi Out Temp</td>
          <td style="font-size:20px;">Lo Out Temp</td>
          <td style="font-size:20px;">Wind RMS</td>
          <td style="font-size:20px;">Hi Gust</td>
          <td style="font-size:20px;">Rain</td>
        </tr>
        <tr>
          <td id='day.outTemp.max.formatted' style='white-space:pre;'></td>
          <td id='day.outTemp.min.formatted' style='white-space:pre;'></td>
          <td id='day.wind.rms.formatted' style='white-space:pre;'></td>
          <td id='day.windGust.max.formatted' style='white-space:pre;'></td>
          <td id='day.rain.sum.formatted' style='white-space:pre;'></td>
        </tr>
      </table>
      <span style="font-size:32px;">Week</span>
      <table style="width:100%;margin:auto;">
        <tr>
          <td style="font-size:20px;">Hi Out Temp</td>
          <td style="font-size:20px;">Lo Out Temp</td>
          <td style="font-size:20px;">Wind RMS</td>
          <td style="font-size:20px;">Hi Gust</td>
          <td style="font-size:20px;">Rain</td>
        </tr>
        <tr>
          <td id='week.outTemp.max.formatted' style='white-space:pre;'></td>
          <td id='week.outTemp.min.formatted' style='white-space:pre;'></td>
          <td id='week.wind.rms.formatted' style='white-space:pre;'></td>
          <td id='week.windGust.max.formatted' style='white-space:pre;'></td>
          <td id='week.rain.sum.formatted' style='white-space:pre;'></td>
        </tr>
      </table>
      <span style="font-size:32px;">Month</span>
      <table style="width:100%;margin:auto;">
        <tr>
          <td style="font-size:20px;">Hi Out Temp</td>
          <td style="font-size:20px;">Lo Out Temp</td>
          <td style="font-size:20px;">Wind RMS</td>
          <td style="font-size:20px;">Hi Gust</td>
          <td style="font-size:20px;">Rain</td>
        </tr>
        <tr>
          <td id='month.outTemp.max.formatted' style='white-space:pre;'></td>
          <td id='month.outTemp.min.formatted' style='white-space:pre;'></td>
          <td id='month.wind.rms.formatted' style='white-space:pre;'></td>
          <td id='month.windGust.max.formatted' style='white-space:pre;'></td>
          <td id='month.rain.sum.formatted' style='white-space:pre;'></td>
        </tr>
      </table>
      <span style="font-size:32px;">Year</span>
      <table style="width:100%;margin:auto;">
        <tr>
          <td style="font-size:20px;">Hi Out Temp</td>
          <td style="font-size:20px;">Lo Out Temp</td>
          <td style="font-size:20px;">Wind RMS</td>
          <td style="font-size:20px;">Hi Gust</td>
          <td style="font-size:20px;">Rain</td>
        </tr>
        <tr>
          <td id='year.outTemp.max.formatted' style='white-space:pre;'></td>
          <td id='year.outTemp.min.formatted' style='white-space:pre;'></td>
          <td id='year.wind.rms.formatted' style='white-space:pre;'></td>
          <td id='year.windGust.max.formatted' style='white-space:pre;'></td>
          <td id='year.rain.sum.formatted' style='white-space:pre;'></td>
        </tr>
      </table>
      <span style="font-size:32px;">Rain Year</span>
      <table style="width:100%;margin:auto;">
        <tr>
          <td style="font-size:20px;">Hi Out Temp</td>
          <td style="font-size:20px;">Lo Out Temp</td>
          <td style="font-size:20px;">Wind RMS</td>
          <td style="font-size:20px;">Hi Gust</td>
          <td style="font-size:20px;">Rain</td>
        </tr>
        <tr>
          <td id='rainyear.outTemp.max.formatted' style='white-space:pre;'></td>
          <td id='rainyear.outTemp.min.formatted' style='white-space:pre;'></td>
          <td id='rainyear.wind.rms.formatted' style='white-space:pre;'></td>
          <td id='rainyear.windGust.max.formatted' style='white-space:pre;'></td>
          <td id='rainyear.rain.sum.formatted' style='white-space:pre;'></td>
        </tr>
      </table>
      <span style="font-size:32px;">All Time</span>
      <table style="width:100%;margin:auto;">
        <tr>
          <td style="font-size:20px;">Hi Out Temp</td>
          <td style="font-size:20px;">Lo Out Temp</td>
          <td style="font-size:20px;">Wind RMS</td>
          <td style="font-size:20px;">Hi Gust</td>
          <td style="font-size:20px;">Rain</td>
        </tr>
        <tr>
          <td id='alltime.outTemp.max.formatted' style='white-space:pre;'></td>
          <td id='alltime.outTemp.min.formatted' style='white-space:pre;'></td>
          <td id='alltime.wind.rms.formatted' style='white-space:pre;'></td>
          <td id='alltime.windGust.max.formatted' style='white-space:pre;'></td>
          <td id='alltime.rain.sum.formatted' style='white-space:pre;'></td>
        </tr>
      </table>
    </div>
  </body>
</html>
