<?php 
include('fixedSettings.php');
include('shared.php');
error_reporting(0);
date_default_timezone_set($TZ);
header('Content-type: text/html; charset=utf-8');
echo "<body style='background-color:#292E35'>";
?>

<!doctype html>
<html>
  <head>
  <meta charset="UTF-8">
  <title>World daylight map</title>
  <script src="https://use.typekit.net/vff2oqo.js"></script>
<script>try{Typekit.load({ async: true });}catch(e){}</script><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="daylightmap/daylightmap.css">

</head>
<body>
<div style="position:relative; top: 30px; left: 0px;">
<?php
echo "<font color='white'>"."World Daylight Map"."</font>";
?>
</div>
<!-- partial:index.partial.html -->
<!--h1>World daylight map</h1>
<p>Equirectangular projection rendered with SVG</p-->
<div class="container" style="top: 80px;">

    <svg id="daylight-map"></svg>
    <div class="controls">
        <!--p class="curr-time">
            <a class="js-skip" data-skip="-60" href="#">
                &lsaquo;
            </a>
            <span></span>
            <a class="js-skip" data-skip="60" href="#">
                &rsaquo;
            </a>
        </p-->
        <!--p class="curr-date">
            <a class="js-skip big-jump" data-skip="-43200" href="#">
                &laquo;
            </a>
            <a class="js-skip" data-skip="-1440" href="#">
                &lsaquo;
            </a>
            <span></span>
            <a class="js-skip" data-skip="1440" href="#">
                &rsaquo;
            </a>
            <a class="js-skip big-jump" data-skip="43200" href="#">
                &raquo;
            </a>
        </p-->
    </div>
</div>

<!--p class="animate"><a href="#" class="js-animate"></a></p-->

<!--p class="credit">Using
    <a href="https://d3js.org/">D3.js</a>,
    <a href="https://github.com/mbostock/d3/wiki/Geo-Projections">Geocode Projections</a>,
    <a href="https://github.com/mbostock/topojson">Topojson</a>,
    <a href="https://github.com/mourner/suncalc">Suncalc</a>,
    <a href="https://www.maxmind.com/en/free-world-cities-database">MaxMind cities</a>,
    <a href="https://momentjs.com/">Moment.js</a>
</p-->
<!-- partial -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.5/d3.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/topojson/1.6.20/topojson.min.js '></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/d3-geo-projection/0.2.16/d3.geo.projection.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.12.0/moment.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.1/moment-timezone.min.js'></script>
<script src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/215059/suncalc.js'></script><script  src="daylightmap/daylightmap.js"></script>

</body>
</html>
